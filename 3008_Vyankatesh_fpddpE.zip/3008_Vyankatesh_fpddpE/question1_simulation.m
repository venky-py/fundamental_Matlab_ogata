%% Q1: UAV Stall Airspeed and Lift-to-Drag Ratio
% Parameters
rho = 1.225; % Air density in kg/m^3
g = 9.81; % Gravitational acceleration in m/s^2
S = 2; % Wing area in m^2
m1 = 20; % Mass 1 in kg
m2 = 30; % Mass 2 in kg
alpha_stall = 15 * pi / 180; % Stall angle in radians

% Lift coefficient
CL = @(alpha) 3 * alpha + 0.2;

% Stall speed for both masses
V_stall_m1 = sqrt((2 * m1 * g) / (rho * S * CL(alpha_stall)));
V_stall_m2 = sqrt((2 * m2 * g) / (rho * S * CL(alpha_stall)));

fprintf('Stall speed for 20 kg mass: %.2f m/s\\n', V_stall_m1);
fprintf('Stall speed for 30 kg mass: %.2f m/s\\n', V_stall_m2);

% Lift-to-Drag ratio
CD = @(alpha) 1.2 * alpha.^2 + 0.05;
alpha = linspace(0, 15 * pi / 180, 100);
L_D_ratio = CL(alpha) ./ CD(alpha);

figure;
plot(rad2deg(alpha), L_D_ratio, 'b', 'LineWidth', 2);
title('Lift-to-Drag Ratio vs Angle of Attack');
xlabel('Angle of Attack (degrees)');
ylabel('L/D Ratio');
grid on;