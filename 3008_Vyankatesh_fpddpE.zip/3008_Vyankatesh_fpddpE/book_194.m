% ------- This is a MATLAB program to find the rise time, peak time,
% maximum overshoot, and settling time of the second-order system
% and higher-order system ------
% ------- In this example, we assume zeta = 0.6 and wn = 5 ------
num = 25; % Numerator of transfer function
den = [1 6 25]; % Denominator of transfer function
t = 0:0.005:5; % Time vector
[y, ~, ~] = step(num, den, t); % Step response

% Calculate rise time (time to reach 1 for the first time)
r = 1;
while r <= length(y) && y(r) < 1.0001
    r = r + 1;
end
rise_time = (r - 1) * 0.005; % Calculate rise time
disp(['Rise Time: ', num2str(rise_time)]);

% Calculate peak time (time at maximum response)
[ymax, tp] = max(y); % Find max value and its index
peak_time = (tp - 1) * 0.005; % Calculate peak time
disp(['Peak Time: ', num2str(peak_time)]);

% Calculate maximum overshoot (amount above 1)
max_overshoot = ymax - 1; % Overshoot is the max response minus 1
disp(['Maximum Overshoot: ', num2str(max_overshoot)]);

% Calculate settling time (time to stay within 2% of the final value)
s = length(y); % Start from the end of the response
while s > 1 && (y(s) < 0.98 || y(s) > 1.02)
    s = s - 1;
end
settling_time = (s - 1) * 0.005; % Calculate settling time
disp(['Settling Time: ', num2str(settling_time)]);
