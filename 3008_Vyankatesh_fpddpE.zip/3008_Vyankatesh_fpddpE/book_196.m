 num = 1;
 den = [1  0.2  1];
 impulse(num,den);
 grid
 title('Unit-Impulse Response of G(s) = 1/(s^2 + 0.2s + 1)')