% ------- Two-dimensional plot and three-dimensional plot of unit-step
% response curves for the standard second-order system with wn = 1
% and zeta = 0, 0.2, 0.4, 0.6, 0.8, and 1. ------
t = 0:0.2:10; % Time vector
zeta = [0 0.2 0.4 0.6 0.8 1]; % Array of damping coefficients
y = zeros(length(t), length(zeta)); % Preallocate y for speed

% Loop to compute step responses
for n = 1:length(zeta)
    num = 1; % Numerator of transfer function
    den = [1 2*zeta(n) 1]; % Denominator of transfer function
    [response, ~, ~] = step(num, den, t); % Compute step response
    y(:, n) = response; % Store response in preallocated matrix
end

% Two-dimensional plot
figure;
plot(t, y);
grid on;
title('Plot of Unit-Step Response Curves with \omega_n = 1 and \zeta = 0, 0.2, 0.4, 0.6, 0.8, 1');
xlabel('t (sec)');
ylabel('Response');
text(4.1, 1.86, '\zeta = 0');
text(3.5, 1.5, '0.2');
text(3.5, 1.24, '0.4');
text(3.5, 1.08, '0.6');
text(3.5, 0.95, '0.8');
text(3.5, 0.86, '1.0');

% Three-dimensional plot
figure;
mesh(t, zeta, y');
title('Three-Dimensional Plot of Unit-Step Response Curves');
xlabel('t (sec)');
ylabel('\zeta');
zlabel('Response');
