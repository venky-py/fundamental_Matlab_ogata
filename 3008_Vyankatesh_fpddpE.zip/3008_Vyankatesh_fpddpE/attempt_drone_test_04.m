clc; clear; close all;

%% Define Drone Parameters
mass = 1.5; % kg
Ixx = 0.02; % Moment of inertia around x-axis (kg.m^2)
Iyy = 0.02; % Moment of inertia around y-axis (kg.m^2)
Izz = 0.04; % Moment of inertia around z-axis (kg.m^2)
gravity = 9.81; % m/s^2

%% Define Improved Stability Matrix (State-Space Representation)
A = [0 1 0 0; 
     0 -1.0 0 0;  % Increased damping for pitch
     0 0 0 1; 
     0 0 0 -1.2]; % Increased damping for roll

B = [0; 1/Ixx; 0; 1/Iyy];
C = eye(4);
D = zeros(4,1);

% Create state-space system
sys = ss(A, B, C, D);

%% Convert State-Space to Transfer Function for PID Application
sys_tf = tf(sys);  % Convert to transfer function
pitch_tf = sys_tf(2,1); % Extract the pitch response (2nd row, 1st column)

%% Define PID Controller Parameters
Kp = 2.0;  % Proportional Gain
Ki = 0.5;  % Integral Gain
Kd = 1.0;  % Derivative Gain

%% Create PID Controller Transfer Function
s = tf('s');
PID = Kp + Ki/s + Kd*s; % Standard PID form

%% Apply PID Control to the Drone System
sys_pid = feedback(PID * pitch_tf, 1); % Apply PID to the pitch response

%% Simulate Step Response with and without PID
time = 0:0.01:5; % 5-second simulation
[y_no_pid, t_no_pid] = step(pitch_tf, time); % Without PID
[y_pid, t_pid] = step(sys_pid, time); % With PID

%% Plot Step Response with PID Control
figure;
plot(t_no_pid, y_no_pid, 'b--', 'LineWidth', 1.5); % Without PID
hold on;
plot(t_pid, y_pid, 'r', 'LineWidth', 2); % With PID
title('Step Response with PID Control for Drone Stability');
xlabel('Time (s)');
ylabel('Response');
legend('Without PID (Pitch)', 'With PID (Pitch)');
grid on;

%% 3D Visualization of Drone Stability with and without PID
figure;
plot3(t_no_pid, y_no_pid, zeros(size(y_no_pid)), 'b--', 'LineWidth', 1.5); % Without PID
hold on;
plot3(t_pid, y_pid, zeros(size(y_pid)), 'r', 'LineWidth', 2); % With PID
xlabel('Time (s)');
ylabel('Pitch Response');
zlabel('Roll Response');
title('3D Visualization of Drone Stability with PID');
legend('Without PID', 'With PID');
grid on;
