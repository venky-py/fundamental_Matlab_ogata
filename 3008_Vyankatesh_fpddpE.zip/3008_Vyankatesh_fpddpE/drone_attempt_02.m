%% Initialize MATLAB and Simscape for Drone Simulation

clc; clear; close all;

% Define Drone Parameters
m = 1.5;  % Mass (kg)
Ixx = 0.03;  % Moment of Inertia around X-axis
Iyy = 0.03;  % Moment of Inertia around Y-axis
Izz = 0.06;  % Moment of Inertia around Z-axis
g = 9.81;  % Gravity (m/s^2)
l = 0.25;  % Arm length (m)
b = 1e-6;  % Thrust coefficient
d = 1e-7;  % Drag coefficient

% Define State Variables
syms x y z phi theta psi dx dy dz dphi dtheta dpsi real
state = [x; y; z; phi; theta; psi; dx; dy; dz; dphi; dtheta; dpsi];

% Control Inputs (Thrust from 4 motors)
syms T1 T2 T3 T4 real
U = [T1; T2; T3; T4];

% Force and Torque Equations
T = b * (T1 + T2 + T3 + T4);  % Total Thrust
Tx = l * b * (T4 - T2);  % Torque about X-axis
Ty = l * b * (T3 - T1);  % Torque about Y-axis
Tz = d * (T1 - T2 + T3 - T4);  % Torque about Z-axis

% Equations of Motion
ddx = (T / m) * (cos(phi) * sin(theta) * cos(psi) + sin(phi) * sin(psi));
ddy = (T / m) * (cos(phi) * sin(theta) * sin(psi) - sin(phi) * cos(psi));
ddz = (T / m) * cos(phi) * cos(theta) - g;

d2phi = Tx / Ixx;
d2theta = Ty / Iyy;
d2psi = Tz / Izz;

% Create System Dynamics
dstate = [dx; dy; dz; dphi; dtheta; dpsi; ddx; ddy; ddz; d2phi; d2theta; d2psi];

% Simulink Model Creation
simTime = 10;  % Simulation time
mdl = 'Quadcopter3D';
open_system(mdl);
