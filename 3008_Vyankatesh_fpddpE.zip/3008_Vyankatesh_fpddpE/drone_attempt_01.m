% MATLAB Code for Drone Stability Analysis

% Define drone parameters (example values, adjust based on your calculations)
mass = 1.5; % kg
Ixx = 0.02; % Moment of inertia around x-axis (kg.m^2)
Iyy = 0.02; % Moment of inertia around y-axis (kg.m^2)
Izz = 0.04; % Moment of inertia around z-axis (kg.m^2)
gravity = 9.81; % m/s^2

% Define state-space representation for stability analysis
A = [0 1 0 0; 0 -0.1 0 0; 0 0 0 1; 0 0 -0.1 0]; % Example dynamics matrix
B = [0; 1/Ixx; 0; 1/Iyy];
C = eye(4);
D = zeros(4,1);

% Create state-space system
sys = ss(A, B, C, D);

% Stability analysis
[eigenvectors, eigenvalues] = eig(A);

% Display results
disp('Eigenvalues of the system:');
disp(diag(eigenvalues));

% Simulate step response
time = 0:0.01:5; % 5-second simulation
[u, t] = step(sys, time);
figure;
plot(t, u);
title('Step Response of the Drone Stability System');
xlabel('Time (s)');
ylabel('Response');
grid on;
