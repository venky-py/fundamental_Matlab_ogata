from fpdf import FPDF # type: ignore

# Create PDF document
pdf = FPDF()
pdf.set_auto_page_break(auto=True, margin=15)
pdf.set_margins(10, 10, 10)
pdf.add_page()
pdf.set_font("Arial", "B", 16)

# Title
pdf.cell(200, 10, "Emergency Response Drone Training Manual", ln=True, align="C")
pdf.ln(10)

# Section 1: Introduction
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "1. Introduction", ln=True)
pdf.set_font("Arial", "", 10)
intro_text = """This manual provides step-by-step guidance for rescue teams to operate the emergency response drone.
The drone is designed for search & rescue, communication relay, and emergency response missions.

Key Features:
- Autonomous Flight – GPS waypoint navigation
- Obstacle Avoidance – RPLIDAR A12 integration
- Virtual Network – Wi-Fi Mesh & LTE connectivity
- Live Video Streaming – Real-time data access
"""
pdf.multi_cell(0, 6, intro_text)
pdf.ln(5)

# Section 2: Drone Components & Hardware
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "2. Drone Components & Hardware", ln=True)
pdf.set_font("Arial", "", 10)
components_text = """Main Components:
- Flight Controller: Pixhawk 4 (Manages flight & stabilization)
- GPS Module: Here3 RTK (Accurate positioning)
- LIDAR Sensor: RPLIDAR A12 (Obstacle detection)
- Battery: 6S LiPo (Provides power)
- Network System: Raspberry Pi 4B (Wi-Fi Mesh & LTE)
"""
pdf.multi_cell(0, 6, components_text)
pdf.ln(5)

# Section 3: Pre-Flight Checks
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "3. Pre-Flight Checks", ln=True)
pdf.set_font("Arial", "", 10)
preflight_text = """Before flying, complete the following:

Physical Inspection:
- Check propellers, motors, and battery condition.
- Ensure the GPS module and LIDAR sensor are secure.
- Confirm network module (Raspberry Pi) is powered on.

Software & Network Setup:
- Power on the drone & connect to the Wi-Fi Mesh or LTE hotspot.
- Open Mission Planner/QGroundControl and check sensor status.
- Wait for 10+ satellites for accurate GPS lock.
"""
pdf.multi_cell(0, 6, preflight_text)
pdf.ln(5)

# Section 4: Basic Drone Operation
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "4. Basic Drone Operation", ln=True)
pdf.set_font("Arial", "", 10)
operation_text = """Manual Flight (RC Controller):
- Arm Motors → Push throttle up slowly.
- Hover Stability → Keep at 2m altitude for initial tests.
- Landing → Reduce throttle gradually until touch-down.

Autonomous Flight (GPS Waypoints):
1. Open Mission Planner → Load map.
2. Set waypoints for the mission area.
3. Click "Upload Mission", then "Start Mission".
4. Monitor flight via telemetry & video feed.
"""
pdf.multi_cell(0, 6, operation_text)
pdf.ln(5)

# Section 5: Virtual Network & Communication
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "5. Virtual Network & Communication", ln=True)
pdf.set_font("Arial", "", 10)
network_text = """Connecting to Wi-Fi Mesh Network:
- Open Wi-Fi settings on a laptop/smartphone.
- Connect to "DroneNet" (password: emergency123).
- Open a browser and access the control dashboard.

LTE Internet Connection (If Available):
- The drone acts as a 4G/5G hotspot.
- Rescue teams can connect for internet access.
"""
pdf.multi_cell(0, 6, network_text)
pdf.ln(5)

# Section 6: Obstacle Detection & Avoidance
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "6. Obstacle Detection & Avoidance", ln=True)
pdf.set_font("Arial", "", 10)
obstacle_text = """LIDAR-Based Obstacle Detection:
- The drone scans the environment in real time.
- If an obstacle is detected within 3 meters, it will reroute automatically.
- Use manual override if necessary.
"""
pdf.multi_cell(0, 6, obstacle_text)
pdf.ln(5)

# Section 7: Emergency Procedures
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "7. Emergency Procedures", ln=True)
pdf.set_font("Arial", "", 10)
emergency_text = """- If the drone loses signal → It will Return-To-Home (RTH) automatically.
- If battery drops below 20% → The drone will auto-land safely.
- If obstacle avoidance fails → Switch to manual mode to guide the drone.
"""
pdf.multi_cell(0, 6, emergency_text)
pdf.ln(5)

# Section 8: Post-Flight & Maintenance
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, "8. Post-Flight & Maintenance", ln=True)
pdf.set_font("Arial", "", 10)
maintenance_text = """- Download flight logs for performance review.
- Recharge battery and inspect for wear & tear.
- Update software/firmware as needed.
"""
pdf.multi_cell(0, 6, maintenance_text)
pdf.ln(10)

# Save the PDF file
pdf_filename = "/mnt/data/Emergency_Response_Drone_Training_Manual.pdf"
pdf.output(pdf_filename)

# Return the file path
pdf_filename
