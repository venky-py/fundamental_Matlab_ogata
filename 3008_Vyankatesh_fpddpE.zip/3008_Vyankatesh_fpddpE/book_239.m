% ------- Unit-Step Response of C(s)/R(s) and Partial-Fraction Expansion of C(s) ------
% Define the numerator and denominator of the transfer function
num = [3 25 72 80];
den = [1 8 40 96 80];

% Plot the unit-step response
figure;
step(num, den); % Plot step response
v = [0 3 0 1.2]; % Axis limits
axis(v); % Set axis limits
grid on; % Add grid to the plot
title('Unit-Step Response of C(s)/R(s)');
xlabel('Time (sec)');
ylabel('Response');

% Partial-Fraction Expansion of C(s)
% Define new numerator and denominator for C(s) = N(s)/D(s)
num1 = [3 25 72 80]; % Numerator of C(s)
den1 = [1 8 40 96 80 0]; % Denominator of C(s), including an extra zero for s=0 pole

% Perform partial-fraction expansion
[r, p, k] = residue(num1, den1);

% Display the results
disp('Residues (r):');
disp(r);
disp('Poles (p):');
disp(p);
disp('Direct Term Coefficients (k):');
disp(k);

% Example output:
% r = Residues
% p = Poles
% k = Direct term coefficients (empty if none exist)
